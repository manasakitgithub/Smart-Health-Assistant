package com.healthassistant;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AppointmentDAO {

    // Book Appointment
    public void bookAppointment(Appointment appointment) {

        String query = "INSERT INTO appointments(patient_id, doctor_id, appointment_date) VALUES (?, ?, ?)";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, appointment.getPatientId());
            ps.setInt(2, appointment.getDoctorId());
            ps.setString(3, appointment.getAppointmentDate());

            int result = ps.executeUpdate();

            if (result > 0) {
                System.out.println("Appointment Booked Successfully!");
            } else {
                System.out.println("Failed to Book Appointment!");
            }

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View Appointments
    public void viewAppointments() {

        String query = "SELECT * FROM appointments";

        try {
            Connection con = DatabaseConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {

                System.out.println("---------------------------");
                System.out.println("Appointment ID : " + rs.getInt("appointment_id"));
                System.out.println("Patient ID     : " + rs.getInt("patient_id"));
                System.out.println("Doctor ID      : " + rs.getInt("doctor_id"));
                System.out.println("Date           : " + rs.getString("appointment_date"));
            }

            rs.close();
            st.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Search Appointment
    public void searchAppointment(int id) {

        String query = "SELECT * FROM appointments WHERE appointment_id=?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                System.out.println("Appointment ID : " + rs.getInt("appointment_id"));
                System.out.println("Patient ID     : " + rs.getInt("patient_id"));
                System.out.println("Doctor ID      : " + rs.getInt("doctor_id"));
                System.out.println("Date           : " + rs.getString("appointment_date"));

            } else {
                System.out.println("Appointment Not Found!");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete Appointment
    public void deleteAppointment(int id) {

        String query = "DELETE FROM appointments WHERE appointment_id=?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            int result = ps.executeUpdate();

            if (result > 0) {
                System.out.println("Appointment Deleted Successfully!");
            } else {
                System.out.println("Appointment Not Found!");
            }

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}