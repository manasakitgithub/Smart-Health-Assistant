package com.healthassistant;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DoctorDAO {

    // Add Doctor
    public void addDoctor(Doctor doctor) {

        String query = "INSERT INTO doctors(doctor_name, specialization, availability) VALUES (?, ?, ?)";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, doctor.getDoctorName());
            ps.setString(2, doctor.getSpecialization());
            ps.setString(3, doctor.getAvailability());

            int result = ps.executeUpdate();

            if (result > 0)
                System.out.println("Doctor Added Successfully!");
            else
                System.out.println("Failed to Add Doctor!");

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View Doctors
    public void viewDoctors() {

        String query = "SELECT * FROM doctors";

        try {
            Connection con = DatabaseConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {

                System.out.println("---------------------------");
                System.out.println("Doctor ID      : " + rs.getInt("doctor_id"));
                System.out.println("Doctor Name    : " + rs.getString("doctor_name"));
                System.out.println("Specialization : " + rs.getString("specialization"));
                System.out.println("Availability   : " + rs.getString("availability"));
            }

            rs.close();
            st.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Search Doctor
    public void searchDoctor(int id) {

        String query = "SELECT * FROM doctors WHERE doctor_id=?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                System.out.println("Doctor ID      : " + rs.getInt("doctor_id"));
                System.out.println("Doctor Name    : " + rs.getString("doctor_name"));
                System.out.println("Specialization : " + rs.getString("specialization"));
                System.out.println("Availability   : " + rs.getString("availability"));

            } else {
                System.out.println("Doctor Not Found!");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update Doctor
    public void updateDoctor(int id, String availability) {

        String query = "UPDATE doctors SET availability=? WHERE doctor_id=?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, availability);
            ps.setInt(2, id);

            int result = ps.executeUpdate();

            if (result > 0)
                System.out.println("Doctor Updated Successfully!");
            else
                System.out.println("Doctor Not Found!");

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete Doctor
    public void deleteDoctor(int id) {

        String query = "DELETE FROM doctors WHERE doctor_id=?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            int result = ps.executeUpdate();

            if (result > 0)
                System.out.println("Doctor Deleted Successfully!");
            else
                System.out.println("Doctor Not Found!");

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}