package com.healthassistant;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PatientDAO dao = new PatientDAO();

        while (true) {

            System.out.println("\n===== SMART HEALTH ASSISTANT =====");
            System.out.println("1. Register Patient");
            System.out.println("2. View All Patients");
            System.out.println("3. Search Patient");
            System.out.println("4. Update Patient");
            System.out.println("5. Delete Patient");
            System.out.println("6. Add Doctor");
            System.out.println("7. View Doctors");
            System.out.println("8. Search Doctor");
            System.out.println("9. Update Doctor");
            System.out.println("10. Delete Doctor");
            System.out.println("11. Book Appointment");
            System.out.println("12. View Appointments");
            System.out.println("13. Search Appointment");
            System.out.println("14. Delete Appointment");
            System.out.println("15. Add Report");
            System.out.println("16. View Reports");
            System.out.println("17. Search Report");
            System.out.println("18. Delete Report");
            System.out.println("19. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

            case 1:
                Patient patient = new Patient();

                System.out.print("Enter Patient Name: ");
                patient.setPatientName(sc.nextLine());

                System.out.print("Enter Age: ");
                patient.setAge(sc.nextInt());
                sc.nextLine();

                System.out.print("Enter Gender: ");
                patient.setGender(sc.nextLine());

                System.out.print("Enter Disease: ");
                patient.setDisease(sc.nextLine());

                dao.addPatient(patient);
                break;

            case 2:
            	System.out.println("Opening patient list...");
                dao.viewPatients();
                System.out.println("Finished viewing patients.");
                break;

            case 3:
                System.out.print("Enter Patient ID: ");
                int id = sc.nextInt();
                dao.searchPatient(id);
                break;
            case 4:
                System.out.print("Enter Patient ID: ");
                int updateId = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter New Disease: ");
                String disease = sc.nextLine();

                dao.updatePatient(updateId, disease);
                break;
            case 5:
                System.out.print("Enter Patient ID to Delete: ");
                int deleteId = sc.nextInt();

                dao.deletePatient(deleteId);
                break;
            case 6:

                Doctor doctor = new Doctor();

                sc.nextLine();

                System.out.print("Enter Doctor Name: ");
                doctor.setDoctorName(sc.nextLine());

                System.out.print("Enter Specialization: ");
                doctor.setSpecialization(sc.nextLine());

                System.out.print("Enter Availability: ");
                doctor.setAvailability(sc.nextLine());

                DoctorDAO doctorDAO = new DoctorDAO();
                doctorDAO.addDoctor(doctor);

                break;

            case 7:

                DoctorDAO doctorDAO1 = new DoctorDAO();
                doctorDAO1.viewDoctors();

                break;

            case 8:

                System.out.print("Enter Doctor ID: ");
                int searchId = sc.nextInt();

                DoctorDAO doctorDAO2 = new DoctorDAO();
                doctorDAO2.searchDoctor(searchId);

                break;

            case 9:

                System.out.print("Enter Doctor ID: ");
                int updateId1= sc.nextInt();
                sc.nextLine();

                System.out.print("Enter New Availability: ");
                String availability = sc.nextLine();

                DoctorDAO doctorDAO3 = new DoctorDAO();
                doctorDAO3.updateDoctor(updateId1, availability);

                break;

            case 10:

                System.out.print("Enter Doctor ID to Delete: ");
                int deleteId1 = sc.nextInt();

                DoctorDAO doctorDAO4 = new DoctorDAO();
                doctorDAO4.deleteDoctor(deleteId1);

                break;
            case 11:

                Appointment appointment = new Appointment();

                System.out.print("Enter Patient ID: ");
                appointment.setPatientId(sc.nextInt());

                System.out.print("Enter Doctor ID: ");
                appointment.setDoctorId(sc.nextInt());

                sc.nextLine();

                System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                appointment.setAppointmentDate(sc.nextLine());

                AppointmentDAO appointmentDAO = new AppointmentDAO();
                appointmentDAO.bookAppointment(appointment);

                break;
            case 12:

                AppointmentDAO appointmentDAO1 = new AppointmentDAO();
                appointmentDAO1.viewAppointments();

                break;
            case 13:

                System.out.print("Enter Appointment ID: ");
                int appointmentId = sc.nextInt();

                AppointmentDAO appointmentDAO2 = new AppointmentDAO();
                appointmentDAO2.searchAppointment(appointmentId);

                break;
            case 14:

                System.out.print("Enter Appointment ID to Delete: ");
                int deleteAppointmentId = sc.nextInt();

                AppointmentDAO appointmentDAO3 = new AppointmentDAO();
                appointmentDAO3.deleteAppointment(deleteAppointmentId);

                break;
            case 15:

                Report report = new Report();

                System.out.print("Enter Patient ID: ");
                report.setPatientId(sc.nextInt());
                sc.nextLine();

                System.out.print("Enter Symptoms: ");
                report.setSymptoms(sc.nextLine());

                System.out.print("Enter Disease: ");
                report.setDisease(sc.nextLine());

                System.out.print("Enter Doctor Name: ");
                report.setDoctor(sc.nextLine());

                System.out.print("Enter Health Tips: ");
                report.setHealthTips(sc.nextLine());

                ReportDAO reportDAO = new ReportDAO();
                reportDAO.addReport(report);

                break;
            case 16:

                ReportDAO reportDAO1 = new ReportDAO();
                reportDAO1.viewReports();

                break;
            case 17:

                System.out.print("Enter Report ID: ");
                int reportId = sc.nextInt();

                ReportDAO reportDAO2 = new ReportDAO();
                reportDAO2.searchReport(reportId);

                break;
            case 18:

                System.out.print("Enter Report ID to Delete: ");
                int deleteReportId = sc.nextInt();

                ReportDAO reportDAO3 = new ReportDAO();
                reportDAO3.deleteReport(deleteReportId);

                break;

            case 19:

                System.out.println("Thank You!");
                sc.close();
                System.exit(0);
                break;


            default:
                System.out.println("Invalid Choice!");
            }
        }
    }
}