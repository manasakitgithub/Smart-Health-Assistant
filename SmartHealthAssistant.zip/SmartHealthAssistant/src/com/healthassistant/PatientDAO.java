package com.healthassistant;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class PatientDAO {

    public void addPatient(Patient patient) {
        String query = "INSERT INTO patients(patient_name, age, gender, disease) VALUES (?, ?, ?, ?)";

        try {
            Connection con = DatabaseConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, patient.getPatientName());
            ps.setInt(2, patient.getAge());
            ps.setString(3, patient.getGender());
            ps.setString(4, patient.getDisease());

            int result = ps.executeUpdate();

            if (result > 0) {
                System.out.println("Patient Registered Successfully!");
            } else {
                System.out.println("Failed to Register Patient!");
            }

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void viewPatients() {
    	

        String query = "SELECT * FROM patients";

        try {
            Connection con = DatabaseConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            if ( !rs.isBeforeFirst()) {
            	System.out.println("No patients found.");
            }

            while (rs.next()) {
                System.out.println("------------------------");
                System.out.println("Patient ID : " + rs.getInt("patient_id"));
                System.out.println("Name       : " + rs.getString("patient_name"));
                System.out.println("Age        : " + rs.getInt("age"));
                System.out.println("Gender     : " + rs.getString("gender"));
                System.out.println("Disease    : " + rs.getString("disease"));
            }

            rs.close();
            st.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void searchPatient(int id) {

        String query = "SELECT * FROM patients WHERE patient_id = ?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Patient ID : " + rs.getInt("patient_id"));
                System.out.println("Name       : " + rs.getString("patient_name"));
                System.out.println("Age        : " + rs.getInt("age"));
                System.out.println("Gender     : " + rs.getString("gender"));
                System.out.println("Disease    : " + rs.getString("disease"));
            } else {
                System.out.println("Patient not found!");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void updatePatient(int id, String disease) {

        String query = "UPDATE patients SET disease = ? WHERE patient_id = ?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, disease);
            ps.setInt(2, id);

            int result = ps.executeUpdate();

            if (result > 0) {
                System.out.println("Patient Updated Successfully!");
            } else {
                System.out.println("Patient Not Found!");
            }

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deletePatient(int id) {

        String query = "DELETE FROM patients WHERE patient_id = ?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            int result = ps.executeUpdate();

            if (result > 0) {
                System.out.println("Patient Deleted Successfully!");
            } else {
                System.out.println("Patient Not Found!");
            }

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
	