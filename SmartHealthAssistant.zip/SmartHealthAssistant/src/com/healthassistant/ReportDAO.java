package com.healthassistant;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReportDAO {

    // Add Report
    public void addReport(Report report) {

        String query = "INSERT INTO reports(patient_id, symptoms, disease, doctor, health_tips) VALUES (?, ?, ?, ?, ?)";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, report.getPatientId());
            ps.setString(2, report.getSymptoms());
            ps.setString(3, report.getDisease());
            ps.setString(4, report.getDoctor());
            ps.setString(5, report.getHealthTips());

            int result = ps.executeUpdate();

            if (result > 0)
                System.out.println("Report Added Successfully!");
            else
                System.out.println("Failed to Add Report!");

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View Reports
    public void viewReports() {

        String query = "SELECT * FROM reports";

        try {
            Connection con = DatabaseConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);

            while (rs.next()) {

                System.out.println("----------------------------");
                System.out.println("Report ID    : " + rs.getInt("report_id"));
                System.out.println("Patient ID   : " + rs.getInt("patient_id"));
                System.out.println("Symptoms     : " + rs.getString("symptoms"));
                System.out.println("Disease      : " + rs.getString("disease"));
                System.out.println("Doctor       : " + rs.getString("doctor"));
                System.out.println("Health Tips  : " + rs.getString("health_tips"));
            }

            rs.close();
            st.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Search Report
    public void searchReport(int id) {

        String query = "SELECT * FROM reports WHERE report_id=?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                System.out.println("Report ID    : " + rs.getInt("report_id"));
                System.out.println("Patient ID   : " + rs.getInt("patient_id"));
                System.out.println("Symptoms     : " + rs.getString("symptoms"));
                System.out.println("Disease      : " + rs.getString("disease"));
                System.out.println("Doctor       : " + rs.getString("doctor"));
                System.out.println("Health Tips  : " + rs.getString("health_tips"));

            } else {
                System.out.println("Report Not Found!");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete Report
    public void deleteReport(int id) {

        String query = "DELETE FROM reports WHERE report_id=?";

        try {
            Connection con = DatabaseConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, id);

            int result = ps.executeUpdate();

            if (result > 0)
                System.out.println("Report Deleted Successfully!");
            else
                System.out.println("Report Not Found!");

            ps.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}