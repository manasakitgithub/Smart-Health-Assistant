/**
 * 
 */
/**
 * 
 */
module SmartHealthAssistant {
	requires java.sql;
}